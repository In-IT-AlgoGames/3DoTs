using Godot;
using System;

public partial class AIPlayer : Player
{
	public AIPlayer(string name, int pointValue) : base(name, pointValue)
	{
	}
}
