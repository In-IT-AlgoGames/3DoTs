using Godot;
using System;

public partial class CoinsToDiamonds : Object
{
	 public void Convert(Player player)
	{
		//if (player.Coins >= 50) // Assuming you have properties instead of methods
		//{
			//player.Coins -= 50;
			//player.Diamonds += 1;
		//}
		//else
		//{
			//GD.Print("Not enough coins!"); // Godot equivalent of System.out.println
		//}
	}
}
